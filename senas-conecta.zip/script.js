function showContent(section) {
  const content = document.getElementById('content');
  if (section === 'abc') {
    content.innerHTML = '<h2>Abecedario en Señas</h2>' + generateAlphabet();
  } else if (section === 'numbers') {
    content.innerHTML = '<h2>Números en Señas</h2><img src="images.jpg" alt="Números en Señas" style="max-width:100%;">';
  } else if (section === 'class') {
    content.innerHTML = '<h2>Clases Profesionales</h2><p>Pronto encontrarás clases detalladas para dominar el lenguaje de señas.</p>';
  } else if (section === 'streaks') {
    content.innerHTML = '<h2>Desafíos</h2>' + generateChallenge();
  }
}

function generateAlphabet() {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
  return '<div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(80px, 1fr));gap:1rem;">' +
    letters.map(letter => `
      <div style="text-align:center">
        <img src="letras/${letter}.jpg" alt="${letter}" style="width:70px;height:70px;object-fit:cover;"><br>
        ${letter}
      </div>`).join('') +
    '</div>';
}

function generateChallenge() {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
  const randomLetter = letters[Math.floor(Math.random() * letters.length)];
  return `
    <p>¿Qué letra es esta?</p>
    <img src="letras/${randomLetter}.jpg" alt="Desafío" style="width:100px;height:100px;"><br>
    <input type="text" id="guess" maxlength="1" placeholder="Escribe la letra">
    <button onclick="checkAnswer('${randomLetter}')">Verificar</button>
    <p id="result"></p>
  `;
}

function checkAnswer(correct) {
  const guess = document.getElementById('guess').value.toUpperCase();
  const result = document.getElementById('result');
  if (guess === correct) {
    result.textContent = '✅ Correcto!';
    result.style.color = 'green';
  } else {
    result.textContent = '❌ Inténtalo de nuevo';
    result.style.color = 'red';
  }
}
